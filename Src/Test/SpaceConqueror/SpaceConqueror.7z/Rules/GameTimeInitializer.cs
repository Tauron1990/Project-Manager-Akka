using JetBrains.Annotations;
using NRules.Fluent.Dsl;
using SpaceConqueror.Rules.Manager;
using SpaceConqueror.States;
using SpaceConqueror.States.GameTime;

namespace SpaceConqueror.Rules;

[UsedImplicitly(ImplicitUseKindFlags.InstantiatedNoFixedConstructorSignature)]
public sealed class GameTimeInitializer : Rule, IManager<GameTimeInitializer, TimeState>
{
    public override void Define()
    {
        TimeState timeState = null!;
        CommandProcessorState processorState = null!;

        When()
           .Match<InitializeGameCommand>()
           .MatchGameTime(() => timeState, t => !t.Stopwatch.IsRunning)
           .MatchCommands(() => processorState);

        Then()
           .Do(ctx => StartTimer(timeState))
           .Do(ctx => AddTickCommand(processorState));
    }

    private void AddTickCommand(CommandProcessorState state)
    {
        if(state.Commands.Contains(GameTimeTickCommand.Inst)) return;

        state.Commands = state.Commands.Add(GameTimeTickCommand.Inst);
    }


    private void StartTimer(TimeState timeState)
        => timeState.Stopwatch.Restart();
}