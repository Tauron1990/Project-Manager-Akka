﻿using JetBrains.Annotations;
using NRules.Fluent.Dsl;
using SpaceConqueror.Rules.Manager;
using SpaceConqueror.States;
using SpaceConqueror.States.GameTime;

namespace SpaceConqueror.Rules;

[UsedImplicitly(ImplicitUseKindFlags.InstantiatedNoFixedConstructorSignature)]
public sealed class GameTimeProcessor : Rule, IManager<GameTimeProcessor, TimeState>
{
    public override void Define()
    {
        TimeState timeState = null!;

        When()
           .MatchCommand<GameTimeTickCommand>()
           .MatchGameTime(() => timeState);

        Then()
           .Do(ctx => UpdateGameTime(timeState));
    }

    private void UpdateGameTime(TimeState timeState)
    {
        TimeSpan lastUpdate = timeState.Stopwatch.Elapsed;
        timeState.Stopwatch.Restart();

        timeState.Current += lastUpdate;
        timeState.LastUpdate = lastUpdate;
    }
}