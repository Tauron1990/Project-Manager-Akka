namespace SpaceConqueror.States;

public interface IState { }