﻿namespace SpaceConqueror.States;

public sealed record InitializeGameCommand : IGameCommand;