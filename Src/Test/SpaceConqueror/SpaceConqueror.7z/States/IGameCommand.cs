namespace SpaceConqueror.States;

public interface IGameCommand { }