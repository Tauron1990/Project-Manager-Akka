namespace SpaceConqueror.States.Actors;

public interface IPlayerParty
{
    string PlayerPosition { get; set; }
}