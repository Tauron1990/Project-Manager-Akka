namespace SpaceConqueror.States.Actors;

public interface IActor { }