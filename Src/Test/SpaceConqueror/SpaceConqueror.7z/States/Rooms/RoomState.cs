﻿using Hyperion.Internal;
using SpaceConqueror.Core;
using SpaceConqueror.States.Rendering;
// ReSharper disable UnusedAutoPropertyAccessor.Global

namespace SpaceConqueror.States.Rooms;

[PublicAPI]
public class RoomState : IState
{
    public RoomState(string id)
        => Id = id;

    public string Id { get; }

    public RoomType RoomType { get; set; }

    public bool IsPlayerInRoom { get; set; }

    public bool ExcludeHistory { get; set; }

    public IDictionary<int, string> PredefinedDescriptions { get; } = new Dictionary<int, string>();

    public IList<string> PredefinedCommands { get; } = new List<string>();

    public IList<string> ProcessorNames { get; } = new List<string>();

    public IEnumerable<object> GetToInsert(AssetManager assetManager, object context)
    {
        foreach (var description in PredefinedDescriptions)
            yield return new AssetDisplayData(description.Key, assetManager, description.Value);

        foreach (string command in PredefinedCommands)
            yield return assetManager.Get<IDisplayCommand>(command);

        foreach (object? processor in from processorName in ProcessorNames
                                      from element in assetManager.Get<ContextProcessor>(processorName)(assetManager, context)
                                      where element is not null
                                      select element)
            yield return processor;
    }
}