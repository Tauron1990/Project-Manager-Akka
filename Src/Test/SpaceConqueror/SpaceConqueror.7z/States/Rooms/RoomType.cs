﻿namespace SpaceConqueror.States.Rooms;

public enum RoomType
{
    Conventinal,
    Dungeon,
    Special
}