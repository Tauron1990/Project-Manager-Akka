﻿using SpaceConqueror.Core;

namespace SpaceConqueror.States.Rooms;

public delegate IEnumerable<object?> ContextProcessor(AssetManager assetManager, object context);