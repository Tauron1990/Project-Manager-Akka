﻿namespace SpaceConqueror.States.Rooms;

public sealed record RoomMoveFailedCommand(string Name);