﻿using SpaceConqueror.States;
using Spectre.Console;

namespace SpaceConqueror.SubMenus;

public class LoadGamesMenu
{
    private readonly GlobalState _globalState;

    public LoadGamesMenu(GlobalState globalState)
        => _globalState = globalState;

    public ValueTask<bool> Show()
    {
        AnsiConsole.Clear();

        var entries = GlobalState.GetSaveGames()
           .Select(s => new LoadEntry(IsExit: false, s))
           .ToList();

        entries.Add(new LoadEntry(IsExit: true, "Zurück"));

        LoadEntry result = AnsiConsole.Prompt(
            new SelectionPrompt<LoadEntry>()
               .AddChoices(entries)
               .UseConverter(e => e.Name)
               .Title("Spiel Laden")
               .HighlightStyle(Styles.SelectionColor));

        if(result.IsExit) return ValueTask.FromResult(result: false);

        _globalState.LoadGame(result.Name);

        return ValueTask.FromResult(result: true);
    }

    private sealed record LoadEntry(bool IsExit, string Name);
}