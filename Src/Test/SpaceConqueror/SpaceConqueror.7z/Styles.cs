﻿using Spectre.Console;

namespace SpaceConqueror;

public sealed class Styles
{
    public static readonly Style SelectionColor = new(Color.Gold3_1);
}