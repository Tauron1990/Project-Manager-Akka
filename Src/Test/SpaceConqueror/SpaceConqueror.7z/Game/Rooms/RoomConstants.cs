﻿namespace SpaceConqueror.Game.Rooms;

public static class RoomConstants
{
    public const string Start = nameof(Start);
}