﻿namespace SpaceConqueror.Game.Rooms;

public class StartModule { }