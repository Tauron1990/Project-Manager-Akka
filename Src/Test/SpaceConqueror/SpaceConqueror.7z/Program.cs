﻿// See https://aka.ms/new-console-template for more information

using SpaceConqueror;
using Spectre.Console;

Console.Title = "Space Conqueror";

GameManager manager = new(Path.GetFullPath("Mods"));

await using (manager.ConfigureAwait(false))
{
   AnsiConsole.WriteLine();

   await AnsiConsole.Status()
     .SpinnerStyle(Style.Parse("orangered1"))
     .StartAsync("Starte Spiel...", manager.Initialize).ConfigureAwait(false);

   AnsiConsole.Clear();

   await manager.Run().ConfigureAwait(false);
}