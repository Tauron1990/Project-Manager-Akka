﻿namespace SpaceConqueror;

public enum MainMenuCommand
{
    NewGame,
    LoadGame,
    Modules,
    Exit
}