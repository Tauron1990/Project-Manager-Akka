namespace SpaceConqueror.Modules;

public sealed record RegistratedModule(string Name, Version Version);