﻿namespace SimpleProjectManagerV2.Shared.Projects;

public static class Errors
{
    public const string NoNewError = "no-new-error";
    public const string NewError = "new-Error";
}