﻿using Grpc.Core;
using SimpleProjectManager.Shared.Services;

namespace SimpleProjectManagerV2.Test;

public class Service : TestService.TestServiceBase
{
    public override Task<TestResponse> Test(TestRequest request, ServerCallContext context)
    {
        return Task.FromResult(new TestResponse());
    }
}